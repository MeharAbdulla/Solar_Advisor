"""Quick test against the local API (run server first)."""
import json
import sys

try:
    import requests
except ImportError:
    print("Install requests: pip install requests")
    sys.exit(1)

# Change to your PC's LAN IP when testing from a phone; use 127.0.0.1 from same machine
BASE = "http://127.0.0.1:8000"  # must match uvicorn --port

# Example: 13 features (matches energy_model + energy_model_features.pkl)
sample = {"features": [4.0, 22.0, 1.0, 12.5, 6.0, 1.0, 1.0, 3.0, 2500.0, 230.0, 22.0, 50.0, 12.5]}

r = requests.post(f"{BASE}/predict", json=sample, timeout=30)
print("Status:", r.status_code)
print(json.dumps(r.json(), indent=2))
