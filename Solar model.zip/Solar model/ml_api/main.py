"""
ML prediction API for Flutter / mobile clients.

Run (from this folder or project root):
  uvicorn main:app --host 0.0.0.0 --port 8000

Test with curl (replace YOUR_PC_IP with your computer's LAN IP, e.g. 192.168.1.10):
  curl -X POST "http://YOUR_PC_IP:8000/predict" -H "Content-Type: application/json" -d "{\\"features\\": [1,2,3,4,5,6,7,8,9,10,11,12,13]}"

Environment variables (optional):
  MODEL_PATH   - path to model.joblib, energy_model.pkl, or solar_rf_energy_bundle.joblib
  SCALER_PATH  - path to scaler.pkl (used only if model is a plain estimator, not a bundle)
  FEATURES_PATH - path to energy_model_features.pkl (optional; used to validate feature count)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, List, Optional, Union

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# --- Paths: ml_api/ is inside "Solar model"; artifacts live in the parent folder by default ---
ML_API_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = ML_API_DIR.parent

MODEL_PATH = os.environ.get("MODEL_PATH", str(PROJECT_ROOT / "model.joblib"))
SCALER_PATH = os.environ.get("SCALER_PATH", str(PROJECT_ROOT / "scaler.pkl"))
FEATURES_PATH = os.environ.get("FEATURES_PATH", str(PROJECT_ROOT / "energy_model_features.pkl"))


class PredictRequest(BaseModel):
    features: List[float] = Field(..., description="Feature values in the training order")


class PredictResponse(BaseModel):
    prediction: Union[float, List[float]]


app = FastAPI(title="ML Predict API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Loaded at startup
_model: Any = None
_scaler: Any = None
_expected_n_features: Optional[int] = None
_feature_cols: Optional[List[str]] = None


def _find_model_file() -> Path:
    """Use MODEL_PATH if it exists; otherwise try common names in PROJECT_ROOT."""
    p = Path(MODEL_PATH)
    if p.is_file():
        return p.resolve()
    for name in ("model.joblib", "energy_model.pkl", "solar_rf_energy_bundle.joblib"):
        alt = PROJECT_ROOT / name
        if alt.is_file():
            return alt.resolve()
    raise FileNotFoundError(
        f"No model file found. Set MODEL_PATH or place one of: model.joblib, "
        f"energy_model.pkl, solar_rf_energy_bundle.joblib in {PROJECT_ROOT}"
    )


def _load_feature_names() -> Optional[List[str]]:
    fp = Path(FEATURES_PATH)
    if not fp.is_file():
        return None
    obj = joblib.load(fp)
    if isinstance(obj, (list, tuple)):
        return list(obj)
    return None


@app.on_event("startup")
def load_artifacts() -> None:
    global _model, _scaler, _expected_n_features, _feature_cols

    model_path = _find_model_file()
    raw = joblib.load(model_path)

    feature_names = _load_feature_names()

    # Bundle from Solar notebook: dict with rf, scaler, train_means, feature_cols
    if isinstance(raw, dict) and "rf" in raw and "scaler" in raw:
        _model = raw["rf"]
        _scaler = raw["scaler"]
        fc = raw.get("feature_cols")
        if fc is not None:
            _feature_cols = list(fc)
            _expected_n_features = len(_feature_cols)
        elif feature_names:
            _expected_n_features = len(feature_names)
            _feature_cols = feature_names
        elif hasattr(_model, "n_features_in_"):
            _expected_n_features = int(_model.n_features_in_)
        print(f"Loaded bundle from {model_path} (RandomForest + scaler).")
        return

    # Plain sklearn model
    _feature_cols = feature_names
    _model = raw
    if hasattr(_model, "n_features_in_"):
        _expected_n_features = int(_model.n_features_in_)

    scaler_path = Path(SCALER_PATH)
    if scaler_path.is_file():
        _scaler = joblib.load(scaler_path)
        print(f"Loaded scaler from {scaler_path}")
    else:
        _scaler = None
        print("No scaler.pkl found; predictions use raw features.")

    if feature_names and _expected_n_features is None:
        _expected_n_features = len(feature_names)

    print(f"Loaded model from {model_path} ({type(_model).__name__}).")


def _prepare_X(features: List[float]) -> np.ndarray:
    if _expected_n_features is not None and len(features) != _expected_n_features:
        raise HTTPException(
            status_code=400,
            detail=f"Expected {_expected_n_features} features, got {len(features)}",
        )
    if _scaler is not None and _feature_cols is not None and len(_feature_cols) == len(features):
        X_df = pd.DataFrame([features], columns=_feature_cols)
        X = _scaler.transform(X_df)
    else:
        X = np.asarray(features, dtype=np.float64).reshape(1, -1)
        if _scaler is not None:
            X = _scaler.transform(X)
    return X


def _predict_value(X: np.ndarray) -> Union[float, List[float]]:
    out = _model.predict(X)
    if hasattr(out, "ravel"):
        out = out.ravel()
    if len(out) == 1:
        return float(out[0])
    return [float(x) for x in out]


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "model_loaded": _model is not None}


@app.get("/model-info")
def model_info() -> dict:
    """Helps clients know how many features to send (order matches training)."""
    return {
        "expected_feature_count": _expected_n_features,
        "feature_names": _feature_cols,
    }


@app.post("/predict", response_model=PredictResponse)
def predict(body: PredictRequest) -> PredictResponse:
    if _model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    X = _prepare_X(body.features)
    result = _predict_value(X)
    return PredictResponse(prediction=result)


@app.get("/")
def root() -> dict:
    return {
        "message": "ML Predict API",
        "docs": "/docs",
        "predict": "POST /predict with JSON {\"features\": [...]}",
    }
